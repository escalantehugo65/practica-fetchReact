# Frontend simple para tu backend de práctica

React + Vite, CSS simple. Sin Tailwind ni React Router para que el recorrido del fetch sea fácil de seguir. Una sola pantalla alterna entre login, registro y tareas.

## Cómo levantarlo
1. Descomprimí frontend-simple en una carpeta nueva, al lado de backend. No reemplaces tu practica-fetch: esta es una referencia para estudiar.
2. Dejá tu backend-practica encendido en el puerto 3000, con MySQL activo.
3. Detené los otros frontends de Vite con Ctrl+C para liberar el puerto 5173.
4. En una terminal dentro de frontend-simple ejecutá npm install.
5. Ejecutá npm run dev y abrí http://localhost:5173.
6. Creá una cuenta (contraseña de al menos 6 caracteres), iniciá sesión y agregá una tarea.

Vite usa estrictamente 5173 porque el backend debe tener FRONTEND_URL=http://localhost:5173. Si el puerto está ocupado, avisa y no inicia. Si necesitás otro puerto, ajustá tanto vite.config.js como FRONTEND_URL en el .env del backend y reiniciá ambos.

## Dónde estudiar
- src/App.jsx: los estados, todas las funciones con fetch y el formulario. Están numeradas y comentadas.
- src/main.jsx: coloca App en la página y carga el CSS.
- src/index.css: estilos sencillos.
- vite.config.js: configura React y el puerto.

Empezá solamente por los estados username, password y la función iniciarSesion. Después mirá el formulario y cómo onChange actualiza esos estados. El resto puede esperar.

## Recordatorio del fetch
«Freno, envío, leo, reviso, muestro».
- preventDefault: evita el envío automático del formulario.
- method: indica GET, POST, PUT o DELETE.
- headers: declara que enviamos JSON.
- JSON.stringify: convierte los datos a texto JSON para enviarlos.
- credentials include: permite recibir/enviar la cookie entre frontend y backend.
- await: espera el resultado de la operación.
- respuesta.json: lee el cuerpo JSON de la respuesta.
- respuesta.ok: comprueba si el estado HTTP indica éxito.
- setUsuario / setTareas: actualizan la pantalla.
- catch: maneja fallos de conexión u otros errores de la operación.
- finally: permite volver a usar los botones al terminar.

## Qué incluye
Registro, login, perfil al abrir/recargar, logout, listado de tareas propias, creación, marcar como terminada/reabrir y eliminación. El token queda en la cookie HttpOnly; no se guarda en localStorage.

Cada función tiene su fetch completo a propósito. Se repiten algunas opciones para que puedas entender cada petición sin saltar entre archivos o funciones genéricas.

## Verificación
Compilación de producción verificada con npm run build y contrato de rutas revisado. La prueba real de sesión y base de datos se realiza con tu backend y MySQL en tu computadora.
