import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  // El backend permite este puerto. Si está ocupado, Vite avisa.
  server: { port: 5173, strictPort: true },
});
