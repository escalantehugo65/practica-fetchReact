import { useEffect, useState } from 'react';

// Todas las peticiones van al mismo backend.
const API = 'http://localhost:3000/api';

export default function App() {
  // ESTADOS: React recuerda estos datos y actualiza la pantalla.
  const [usuario, setUsuario] = useState(null);
  const [verificando, setVerificando] = useState(true);
  const [registrarse, setRegistrarse] = useState(false);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [lastname, setLastname] = useState('');
  const [email, setEmail] = useState('');
  const [mensaje, setMensaje] = useState('');
  const [ocupado, setOcupado] = useState(false);
  const [tareas, setTareas] = useState([]);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');

  // 1. PERFIL: la cookie viaja automáticamente; React no lee el token.
  async function cargarPerfil() {
    const respuesta = await fetch(`${API}/profile`, {
      credentials: 'include',
    });
    if (respuesta.status === 401) {
      setUsuario(null);
      setTareas([]);
      return false;
    }
    const datos = await respuesta.json();
    if (!respuesta.ok) throw new Error(datos.message || 'No se pudo consultar la sesión');
    setUsuario(datos.user);
    return true;
  }

  // 2. LISTAR: GET es el método por defecto de fetch.
  async function cargarTareas() {
    const respuesta = await fetch(`${API}/tasks`, {
      credentials: 'include',
    });
    const datos = await respuesta.json();
    if (respuesta.status === 401) {
      setUsuario(null);
      setTareas([]);
    }
    if (!respuesta.ok) throw new Error(datos.message || 'No se pudieron cargar las tareas');
    setTareas(datos);
  }

  // Se ejecuta al abrir la app: comprueba si ya existe una sesión.
  useEffect(() => {
    async function iniciar() {
      try {
        const haySesion = await cargarPerfil();
        if (haySesion) await cargarTareas();
      } catch (error) {
        setMensaje(`No se pudo iniciar la app: ${error.message}. Revisá que el backend esté encendido.`);
      } finally {
        setVerificando(false);
      }
    }
    iniciar();
  }, []);

  // 3. LOGIN: freno el formulario, envío JSON, reviso y muestro.
  async function iniciarSesion(evento) {
    evento.preventDefault();
    setMensaje('');
    setOcupado(true);
    try {
      const respuesta = await fetch(`${API}/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ username, password }),
      });
      const datos = await respuesta.json();
      // fetch no lanza un error por un 401: hay que revisar ok.
      if (!respuesta.ok) {
        setMensaje(datos.message);
        return;
      }
      setPassword('');
      const haySesion = await cargarPerfil();
      if (!haySesion) {
        setMensaje('No se pudo confirmar la sesión');
        return;
      }
      await cargarTareas();
    } catch (error) {
      setMensaje(`No se pudo completar el ingreso: ${error.message}`);
    } finally {
      setOcupado(false);
    }
  }

  // 4. REGISTRO: crea el usuario y vuelve al formulario de login.
  async function registrarUsuario(evento) {
    evento.preventDefault();
    setMensaje('');
    setOcupado(true);
    try {
      const respuesta = await fetch(`${API}/register`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ name, lastname, username, email, password }),
      });
      const datos = await respuesta.json();
      if (!respuesta.ok) {
        setMensaje(datos.message);
        return;
      }
      setRegistrarse(false);
      setPassword('');
      setMensaje('Usuario creado. Ahora iniciá sesión.');
    } catch (error) {
      setMensaje(`No se pudo registrar: ${error.message}`);
    } finally {
      setOcupado(false);
    }
  }

  // 5. SALIR: el backend elimina la cookie; limpiamos la pantalla.
  async function cerrarSesion() {
    setOcupado(true);
    setMensaje('');
    try {
      const respuesta = await fetch(`${API}/logout`, {
        method: 'POST',
        credentials: 'include',
      });
      const datos = await respuesta.json();
      if (!respuesta.ok) {
        setMensaje(datos.message);
        return;
      }
      setUsuario(null);
      setTareas([]);
      setPassword('');
      setTitle('');
      setDescription('');
    } catch (error) {
      setMensaje(`No se pudo cerrar sesión: ${error.message}`);
    } finally {
      setOcupado(false);
    }
  }

  // 6. CREAR: el backend obtiene el dueño de la tarea desde la cookie.
  async function crearTarea(evento) {
    evento.preventDefault();
    setOcupado(true);
    setMensaje('');
    try {
      const respuesta = await fetch(`${API}/tasks`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ title, description }),
      });
      const datos = await respuesta.json();
      if (!respuesta.ok) {
        setMensaje(datos.message);
        if (respuesta.status === 401) { setUsuario(null); setTareas([]); }
        return;
      }
      setTitle('');
      setDescription('');
      await cargarTareas();
    } catch (error) {
      setMensaje(`No se pudo completar la operación: ${error.message}`);
    } finally {
      setOcupado(false);
    }
  }

  // 7. COMPLETAR: PUT modifica una tarea existente.
  async function cambiarEstado(tarea) {
    setOcupado(true);
    setMensaje('');
    try {
      const respuesta = await fetch(`${API}/tasks/${tarea.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ is_completed: !tarea.is_completed }),
      });
      const datos = await respuesta.json();
      if (!respuesta.ok) {
        setMensaje(datos.message);
        if (respuesta.status === 401) { setUsuario(null); setTareas([]); }
        return;
      }
      await cargarTareas();
    } catch (error) {
      setMensaje(`No se pudo completar la operación: ${error.message}`);
    } finally {
      setOcupado(false);
    }
  }

  // 8. ELIMINAR: DELETE identifica la tarea por su id en la URL.
  async function eliminarTarea(id) {
    setOcupado(true);
    setMensaje('');
    try {
      const respuesta = await fetch(`${API}/tasks/${id}`, {
        method: 'DELETE',
        credentials: 'include',
      });
      const datos = await respuesta.json();
      if (!respuesta.ok) {
        setMensaje(datos.message);
        if (respuesta.status === 401) { setUsuario(null); setTareas([]); }
        return;
      }
      await cargarTareas();
    } catch (error) {
      setMensaje(`No se pudo completar la operación: ${error.message}`);
    } finally {
      setOcupado(false);
    }
  }

  // PANTALLA: si hay usuario, muestra tareas; si no, login/registro.
  return (
    <main>
      <h1>Mis tareas</h1>
      {mensaje && <p className="mensaje" role="status">{mensaje}</p>}

      {verificando ? <p>Comprobando sesión…</p> : !usuario ? (
        <section>
          <h2>{registrarse ? 'Crear una cuenta' : 'Iniciar sesión'}</h2>
          <form onSubmit={registrarse ? registrarUsuario : iniciarSesion}>
            <fieldset disabled={ocupado}>
              {registrarse && <>
                <label>Nombre<input value={name} onChange={(e) => setName(e.target.value)} required maxLength={100} autoComplete="given-name" /></label>
                <label>Apellido<input value={lastname} onChange={(e) => setLastname(e.target.value)} required maxLength={100} autoComplete="family-name" /></label>
                <label>Email<input type="email" value={email} onChange={(e) => setEmail(e.target.value)} required maxLength={100} autoComplete="email" /></label>
              </>}
              <label>Usuario<input value={username} onChange={(e) => setUsername(e.target.value)} required maxLength={100} autoComplete="username" /></label>
              <label>Contraseña<input type="password" value={password} onChange={(e) => setPassword(e.target.value)} required minLength={registrarse ? 6 : undefined} autoComplete={registrarse ? 'new-password' : 'current-password'} /></label>
              <button type="submit">{ocupado ? 'Esperá…' : registrarse ? 'Registrarme' : 'Ingresar'}</button>
            </fieldset>
          </form>
          <button className="secundario" disabled={ocupado} onClick={() => { setRegistrarse(!registrarse); setMensaje(''); setPassword(''); }}>
            {registrarse ? 'Ya tengo una cuenta' : 'Crear una cuenta'}
          </button>
        </section>
      ) : (
        <section>
          <header><h2>Hola, {usuario.name}</h2><button className="secundario" onClick={cerrarSesion} disabled={ocupado}>Cerrar sesión</button></header>
          <form onSubmit={crearTarea}>
            <fieldset disabled={ocupado}>
              <label>Título<input value={title} onChange={(e) => setTitle(e.target.value)} required maxLength={100} /></label>
              <label>Descripción<textarea value={description} onChange={(e) => setDescription(e.target.value)} maxLength={100} /></label>
              <button type="submit">Agregar tarea</button>
            </fieldset>
          </form>
          <h3>Tu lista</h3>
          {tareas.length === 0 && <p>Todavía no tenés tareas.</p>}
          <ul>{tareas.map((tarea) => (
            <li key={tarea.id}>
              <div><strong className={tarea.is_completed ? 'completada' : ''}>{tarea.title}</strong><p>{tarea.description}</p><small>{tarea.is_completed ? 'Terminada' : 'Pendiente'}</small></div>
              <div className="acciones">
                <button className="secundario" disabled={ocupado} onClick={() => cambiarEstado(tarea)}>{tarea.is_completed ? 'Reabrir' : 'Completar'}</button>
                <button className="eliminar" disabled={ocupado} onClick={() => eliminarTarea(tarea.id)}>Eliminar</button>
              </div>
            </li>
          ))}</ul>
        </section>
      )}
    </main>
  );
}
